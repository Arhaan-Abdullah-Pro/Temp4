# self_check.py — quick project sanity test
from pathlib import Path
import json, joblib, pandas as pd

BASE = Path(__file__).resolve().parent
DATA = BASE / "Datasets"
MODELS = BASE / "models"

ok = True

print("== Checking datasets ==")
for name in ["PdM_telemetry.csv","PdM_failures.csv","PdM_errors.csv","PdM_maint.csv","PdM_machines.csv"]:
    p = DATA / name
    if p.exists():
        try:
            pd.read_csv(p, nrows=5)
            print("  ✓", name)
        except Exception as e:
            ok = False
            print("  ✗", name, "-", type(e).__name__, e)
    else:
        ok = False
        print("  ✗ missing:", name)

print("\n== Checking models ==")
for name in ["ensemble_model.pkl", "rf_model.pkl", "svc_pipeline.pkl", "logreg_model.pkl"]:
    p = MODELS / name
    if p.exists():
        try:
            joblib.load(p)
            print("  ✓", name)
        except Exception as e:
            ok = False
            print("  ✗", name, "-", type(e).__name__, e)
    else:
        ok = False
        print("  ✗ missing:", name)

print("\n== Checking thresholds ==")
for name in ["threshold_realtime.json"]:
    p = MODELS / name
    if p.exists():
        try:
            with open(p, "r", encoding="utf-8") as f:
                json.load(f)
            print("  ✓", name)
        except Exception as e:
            ok = False
            print("  ✗", name, "-", type(e).__name__, e)
    else:
        ok = False
        print("  ✗ missing:", name)

print("\nOverall:", "PASS" if ok else "FAIL")
