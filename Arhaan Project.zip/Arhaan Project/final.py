# ========================= final.py (drop-in replacement) =========================
import os, json
from pathlib import Path

import streamlit as st
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from pmdarima.arima import auto_arima
from statsmodels.tsa.arima.model import ARIMA
from statsmodels.tsa.stattools import adfuller, kpss
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, confusion_matrix, f1_score, classification_report, precision_score, recall_score
from sklearn.ensemble import RandomForestClassifier, VotingClassifier
from sklearn.model_selection import train_test_split
from sklearn.svm import SVC
from sklearn.preprocessing import LabelEncoder, StandardScaler
from imblearn.over_sampling import SMOTE
try:
    from catboost import CatBoostClassifier  # optional
except Exception:
    CatBoostClassifier = None
from sklearn.pipeline import Pipeline
import altair as alt
import joblib
import re as _re

# ---------------------------------------------------------------------------------
# Helpers: paths, dataset loading, model loading, threshold loading
# ---------------------------------------------------------------------------------
BASE_DIR = Path(__file__).resolve().parent

def _resolve_path(rel: str) -> Path:
    """Resolve relative path robustly: first relative to this file, then CWD."""
    p1 = (BASE_DIR / rel).resolve()
    if p1.exists():
        return p1
    return (Path.cwd() / rel).resolve()

def _read_csv_safe(rel: str, parse_dates=None) -> pd.DataFrame:
    """Read CSV, trying both BASE_DIR and CWD. Show a friendly error if missing."""
    p = _resolve_path(rel)
    try:
        kw = {"low_memory": False}
        if parse_dates is not None:
            kw["parse_dates"] = parse_dates
        return pd.read_csv(p, **kw)
    except Exception as e:
        st.error(f"❌ Could not read CSV: `{rel}` (tried `{p}`)\n\n**{type(e).__name__}**: {e}")
        return pd.DataFrame()

def _coerce_datetime(df: pd.DataFrame, col: str = "datetime") -> pd.DataFrame:
    """Ensure df[col] is datetime64[ns]; leave df untouched if col missing."""
    if col in df.columns:
        df[col] = pd.to_datetime(df[col], errors="coerce")
    return df

def _load_model_fallback(rel_model_path: str):
    """
    Load a model trying:
      - models/<name>.pkl
      - models/models/<name>.pkl
    Returns the model or None; shows a friendly message if missing.
    """
    tries = [
        _resolve_path(rel_model_path),
        _resolve_path(rel_model_path.replace("models/", "models/models/")),
    ]
    last_err = None
    for p in tries:
        try:
            return joblib.load(p)
        except Exception as e:
            last_err = e
    st.warning(f"⚠️ Model not found: `{rel_model_path}` (also tried nested models/). "
               f"Details: {type(last_err).__name__}: {last_err}")
    return None

def _load_threshold(default: float = 0.5, fname: str = "models/threshold_realtime.json") -> float:
    """Load tuned threshold; fallback to default and alt path if needed."""
    for candidate in [fname, "models/models/threshold_realtime.json"]:
        p = _resolve_path(candidate)
        try:
            with open(p, "r", encoding="utf-8") as f:
                return float(json.load(f).get("thr", default))
        except Exception:
            continue
    return default

# ---- Domain helpers for this dataset ----
def build_telemetry_daily(df_tele: pd.DataFrame) -> pd.DataFrame:
    """Daily averages of telemetry."""
    df = df_tele.copy()
    _coerce_datetime(df, "datetime")
    g = df.groupby(['machineID', pd.Grouper(key='datetime', freq='D')]).sum(numeric_only=True).reset_index()
    for c in ['pressure','volt','vibration','rotate']:
        if c in g.columns:
            g[c] = g[c] / 24.0
    return g.dropna()

def build_failures_daily(df_fail: pd.DataFrame) -> pd.DataFrame:
    """
    Convert PdM_failures into a per-day/per-machine binary 'failure' column.
    Any failure event that day → failure=1, otherwise 0 after merge.
    """
    df = df_fail.copy()
    _coerce_datetime(df, "datetime")
    df["datetime"] = df["datetime"].dt.floor("D")
    df["failure_flag"] = 1
    daily = df.groupby(["machineID", "datetime"], as_index=False)["failure_flag"].sum()
    daily["failure"] = (daily["failure_flag"] > 0).astype(int)
    return daily[["machineID", "datetime", "failure"]]

def build_errors_daily(df_errors: pd.DataFrame) -> pd.DataFrame:
    """Daily count of errors per machine."""
    df = df_errors.copy()
    _coerce_datetime(df, "datetime")
    df["datetime"] = df["datetime"].dt.floor("D")
    out = df.groupby(["machineID","datetime"], as_index=False).size()
    out = out.rename(columns={"size":"error_count"})
    out["error_count"] = out["error_count"].astype(int)
    return out

def build_maint_daily(df_maint: pd.DataFrame) -> pd.DataFrame:
    """Daily count of maintenance per machine."""
    df = df_maint.copy()
    _coerce_datetime(df, "datetime")
    df["datetime"] = df["datetime"].dt.floor("D")
    out = df.groupby(["machineID","datetime"], as_index=False).size()
    out = out.rename(columns={"size":"maint_count"})
    out["maint_count"] = out["maint_count"].astype(int)
    return out

def build_full_daily_dataset(
    df_tele: pd.DataFrame,
    df_fail: pd.DataFrame,
    df_err: pd.DataFrame,
    df_maint: pd.DataFrame,
    df_machines: pd.DataFrame
) -> pd.DataFrame:
    """
    Augmented, per-day, per-machine dataset with:
    - telemetry daily means (volt, rotate, pressure, vibration)
    - failure (0/1)
    - error_count, maint_count
    - rolling features: err_last3 (3-day errors), mnt_last7 (7-day maint)
    - machine attributes: age, model
    """
    tele_daily = build_telemetry_daily(df_tele)
    fail_daily = build_failures_daily(df_fail)
    err_daily  = build_errors_daily(df_err)
    mnt_daily  = build_maint_daily(df_maint)

    df = tele_daily.merge(fail_daily, on=["machineID","datetime"], how="left")
    df = df.merge(err_daily, on=["machineID","datetime"], how="left")
    df = df.merge(mnt_daily, on=["machineID","datetime"], how="left")

    df["failure"] = df["failure"].fillna(0).astype(int)
    for c in ["error_count","maint_count"]:
        if c in df.columns:
            df[c] = df[c].fillna(0).astype(int)
        else:
            df[c] = 0

    # add machine attributes
    mach = df_machines.copy()
    if "model" in mach.columns:
        mach["model"] = mach["model"].astype(str)
    df = df.merge(mach[["machineID","age","model"]], on="machineID", how="left")

    # rolling features (by machine over time)
    df = df.sort_values(["machineID","datetime"]).reset_index(drop=True)
    df["err_last3"] = (
        df.groupby("machineID")["error_count"]
          .transform(lambda s: s.rolling(window=3, min_periods=1).sum())
    )
    df["mnt_last7"] = (
        df.groupby("machineID")["maint_count"]
          .transform(lambda s: s.rolling(window=7, min_periods=1).sum())
    )

    return df

# ---------------------------------------------------------------------------------
# Streamlit setup
# ---------------------------------------------------------------------------------
st.set_page_config(page_title="Predictive Model", page_icon="📈")

# ---------------------------------------------------------------------------------
# Page 1 — Data collection & pre-processing
# ---------------------------------------------------------------------------------
def page1():
    st.title(":blue[DATA COLLECTION AND PRE-PROCESSING]")

    df  = _read_csv_safe("Datasets/PdM_telemetry.csv", parse_dates=["datetime"])
    df1 = _read_csv_safe("Datasets/PdM_machines.csv")
    df2 = _read_csv_safe("Datasets/PdM_failures.csv", parse_dates=["datetime"])
    df3 = _read_csv_safe("Datasets/PdM_errors.csv", parse_dates=["datetime"])
    df4 = _read_csv_safe("Datasets/PdM_maint.csv", parse_dates=["datetime"])

    if df.empty:
        return

    st.subheader("Telemetry Data");  st.dataframe(df)
    st.subheader("Machines Data");   st.dataframe(df1)
    st.subheader("Failure Data");    st.dataframe(df2)
    st.subheader("Errors Data");     st.dataframe(df3)
    st.subheader("Maintenance Data");st.dataframe(df4)

    telemetry_daily = build_telemetry_daily(df)
    st.subheader("Telemetry Daily Data"); st.dataframe(telemetry_daily)

    # 🔹 Augmented dataset preview with new features
    with st.expander("🔎 Augmented Daily Dataset (with new features)", expanded=True):
        full_daily = build_full_daily_dataset(df, df2, df3, df4, df1)
        cols_to_show = ['machineID','datetime','volt','rotate','pressure','vibration',
                        'failure','error_count','maint_count','err_last3','mnt_last7','age','model']
        st.dataframe(full_daily[cols_to_show].head(200))
        st.caption("Includes new columns: error_count, maint_count, err_last3, mnt_last7, age, model.")

    # --- Existing visuals (unchanged) ---
    df_no2016 = df[df['datetime'].dt.year != 2016].sort_values(by='datetime')

    st.divider()
    st.header(":blue[Outlier Detection and Replacement]")
    tele = _read_csv_safe("Datasets/PdM_telemetry.csv")
    st.write("Dataset"); st.dataframe(tele.head())

    st.subheader("Boxplot Analysis (Pressure)")
    df_pressure = tele['pressure']
    median_pressure = df_pressure.median()
    st.write(f":blue[Median Pressure: {median_pressure}]")
    fig, ax = plt.subplots(); sns.boxplot(x=df_pressure, ax=ax); st.pyplot(fig)

    Q1 = df_pressure.quantile(0.25); Q3 = df_pressure.quantile(0.75); IQR = Q3 - Q1
    lower = Q1 - 1.5*IQR; upper = Q3 + 1.5*IQR
    tele["pressure"] = np.where(tele["pressure"] >= upper, tele['pressure'].median(), tele['pressure'])
    tele["pressure"] = np.where(tele["pressure"] <= lower, tele['pressure'].median(), tele['pressure'])
    df_pressure2 = tele['pressure']; median_pressure2 = df_pressure2.median()

    st.subheader("Boxplot after outlier removal")
    fig, ax = plt.subplots(); sns.boxplot(x=df_pressure2, ax=ax); st.pyplot(fig)
    st.subheader("Pressure Outliers Boundaries")
    st.write("Min:", lower); st.write("Max:", upper); st.write("Median:", median_pressure2)

    st.divider()
    st.title(" :blue[Trend over the year]")
    st.subheader("Hourly Variation")
    st.subheader("Variation of Pressure over Time")
    fig = plt.figure(figsize=(20, 10))
    plt.plot(df_no2016['datetime'], df_no2016['pressure'], color='blue')
    plt.xlabel("Datetime"); plt.ylabel("Pressure"); plt.title("Pressure Variation over Time")
    st.pyplot(fig)

    st.subheader("Statistical Summary of Telemetry Attributes")
    data = {
        'Attribute': ['Pressure', 'Vibration','Voltage','Rotation'],
        'Max': ['185.951997730866','76.7910723016723','255.124717259791','695.020984403396'],
        'Date (Max)':['2015-04-04 21:00:00','2015-04-06 04:00:00','2015-11-16 07:00:00','2015-10-27 22:00:00'],
        'Min': ['51.2371057734253','14.877053998383','97.333603782359','138.432075304341'],
        'Date (Min)':['2015-09-22 00:00:00','2015-07-04 06:00:00','2015-08-31 04:00:00','2015-09-25 08:00:00']
    }
    df_tbl = pd.DataFrame(data)
    st.table(df_tbl.style.set_properties(**{'text-align': 'center'}).set_table_styles([{
        'selector': 'th', 'props': [('text-align', 'center')]
    }]))

# ---------------------------------------------------------------------------------
# Page 2 — Machines, errors & failures
# ---------------------------------------------------------------------------------
def page2():
    st.title(":blue[MACHINES, ERRORS & FAILURES]")
    merged_df = _read_csv_safe("Datasets/PdM_failures.csv", parse_dates=["datetime"])
    df1 = _read_csv_safe("Datasets/PdM_machines.csv")
    if merged_df.empty or df1.empty:
        return

    merged_df['failure'] = merged_df['failure'].astype(str)
    label_encoder = LabelEncoder()
    merged_df['failure_encoded'] = label_encoder.fit_transform(merged_df['failure']) + 1

    machfail = pd.merge(df1, merged_df, on="machineID", how="inner")
    machfail['datetime'] = pd.to_datetime(machfail['datetime'])
    min_datetime = machfail['datetime'].min()
    machfail['days'] = ((machfail['datetime'] - min_datetime).dt.days) + 2

    st.subheader("Failure trend for Machine")
    machine_id = st.number_input("Enter the machine ID:", value=1, min_value=1)
    machine_df = machfail[machfail['machineID'] == machine_id]
    machine_id_1_df = merged_df[merged_df['machineID'] == machine_id]

    failure_trends = machine_id_1_df.groupby('failure')['failure_encoded'].size()
    fig, ax = plt.subplots(figsize=(10, 6))
    failure_trends.plot(kind='bar', color='red', ax=ax)
    ax.set_title(f"Frequency of Failure for Machine ID - {machine_id}")
    ax.set_ylabel("Count"); ax.set_xlabel("Failure Type")
    st.pyplot(fig)

    failure_trend = machine_df.groupby('datetime')['failure_encoded'].sum()
    fig, ax = plt.subplots(figsize=(15, 8))
    ax.plot(failure_trend.index, failure_trend.values, marker='o')
    ax.set_title(f"Failure Trend for Machine ID - {machine_id}")
    ax.set_xlabel('Date'); ax.set_ylabel('Failure'); ax.grid(True)
    st.pyplot(fig)

    machine_id_1_df = machfail[machfail['machineID'] == machine_id].drop(['model', 'age'], axis=1)
    machine_id_1_df['Difference'] = machine_id_1_df['days'].diff()
    st.write(machine_id_1_df)
    sum_diff = machine_id_1_df['Difference'].sum()
    mean_diff = sum_diff / max(1, (len(machine_id_1_df) - 1))
    st.write(f":blue[Average number of days between two failures for Machine ID: {machine_id} -] {int(mean_diff)}")

    # Error analytics
    st.divider()
    df = _read_csv_safe("Datasets/PdM_errors.csv", parse_dates=["datetime"])
    if df.empty:
        return
    df = df.sort_values(by='errorID')
    df = df[df['datetime'].dt.year != 2016]
    label_encoder = LabelEncoder()
    df['errorID_encoded'] = label_encoder.fit_transform(df['errorID']) + 1
    errors = df.groupby('errorID')['errorID_encoded'].size()

    plt.figure(figsize=(10, 6))
    errors.plot(kind='bar', color='red')
    st.subheader("Frequency of Errors")
    plt.title('Frequency of Errors'); plt.xlabel('ErrorID'); plt.ylabel('No. of Errors')
    st.pyplot(plt)

    st.subheader('Monthly Variation of Errors')
    df['month'] = df['datetime'].dt.month
    monthly_errors = df.groupby('month')['errorID_encoded'].size()
    month_names = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec']

    plt.figure(figsize=(20, 10))
    plt.plot(monthly_errors.index, monthly_errors.values, color='blue', marker='o')
    plt.title('Monthly Variation of Errors'); plt.xlabel('Month'); plt.ylabel('Errors')
    plt.xticks(monthly_errors.index, month_names); plt.grid(True)
    st.pyplot(plt)

    avg_errors = df.groupby('machineID')['errorID_encoded'].size()
    plt.figure(figsize=(20,6)); plt.title('Variation of Errors by machine ID')
    avg_errors.plot(kind='bar'); st.pyplot(plt)

    avg_errors = df.drop('errorID_encoded', axis=1).groupby('machineID').size()
    top_3_most_errors = avg_errors.nlargest(3).rename_axis('Machine ID').reset_index(name='No of errors')
    top_3_least_errors = avg_errors.nsmallest(3).rename_axis('Machine ID').reset_index(name='No of errors')
    st.write("Top 3 Machine IDs with Most Errors:"); st.write(top_3_most_errors)
    st.write("Top 3 Machine IDs with Least Errors:"); st.write(top_3_least_errors)

# ---------------------------------------------------------------------------------
# Page 3 — Machines + telemetry correlations (fixed merges)
# ---------------------------------------------------------------------------------
def page3():
    st.subheader(":blue[Variation of Telemetry Attributes wrt Age of Machine]")

    df1 = _read_csv_safe("Datasets/PdM_machines.csv")
    df  = _read_csv_safe("Datasets/PdM_telemetry.csv", parse_dates=["datetime"])
    if df1.empty or df.empty:
        return

    telemetry_daily = build_telemetry_daily(df)
    merged_df = pd.merge(telemetry_daily, df1, on=['machineID'], how='left')

    mean_pressure_by_age = merged_df.groupby('age')['pressure'].mean()
    plt.figure(); plt.plot(mean_pressure_by_age.index, mean_pressure_by_age.values, marker='o')
    plt.title('Mean Pressure Variation by Age'); plt.xlabel('Age'); plt.ylabel('Mean Pressure')
    st.pyplot(plt)

    mean_rotation_by_age = merged_df.groupby('age')['rotate'].mean()
    plt.figure(); plt.plot(mean_rotation_by_age.index, mean_rotation_by_age.values, marker='o', color='red')
    plt.title('Mean rotation Variation by Age'); plt.xlabel('Age'); plt.ylabel('Mean rotation')
    st.pyplot(plt)

    mean_voltage_by_age = merged_df.groupby('age')['volt'].mean()
    plt.figure(); plt.plot(mean_voltage_by_age.index, mean_voltage_by_age.values, marker='o', color='green')
    plt.title('Mean voltage Variation by Age'); plt.xlabel('Age'); plt.ylabel('Mean voltage')
    st.pyplot(plt)

    mean_vibration_by_age = merged_df.groupby('age')['vibration'].mean()
    plt.figure(); plt.plot(mean_vibration_by_age.index, mean_vibration_by_age.values, marker='o', color='orange')
    plt.title('Mean vibration Variation by Age'); plt.xlabel('Age'); plt.ylabel('Mean vibration')
    st.pyplot(plt)

    st.divider()
    st.subheader("Variation of Failure Components wrt Telemetry Attributes")

    # Load failures; merge on exact hour with telemetry
    df2 = _read_csv_safe("Datasets/PdM_failures.csv", parse_dates=["datetime"])
    if df2.empty:
        return

    df_ok  = _coerce_datetime(df.copy(), "datetime")
    df2_ok = _coerce_datetime(df2.copy(), "datetime")

    df2_sel = df2_ok[['machineID', 'datetime', 'failure']]
    df_fail_join = pd.merge(df_ok, df2_sel, on=['machineID','datetime'], how='inner')
    mer = pd.merge(df_fail_join, df1, on="machineID", how="left")

    if df_fail_join.empty:
        st.info("No telemetry rows match exact failure timestamps. Try daily joins on other pages.")
        return

    plt.figure(figsize=(10, 6))
    plt.scatter(df_fail_join['failure'], df_fail_join['pressure'], s=50, alpha=0.5)
    plt.title('Variation of Pressure wrt Failure Components'); plt.xlabel('Failure Component'); plt.ylabel('Pressure'); plt.grid(True)
    st.pyplot(plt)

    plt.figure(figsize=(10, 6))
    plt.scatter(df_fail_join['failure'], df_fail_join['rotate'], s=50, alpha=0.5)
    plt.title('Variation of Rotation wrt Failure Components'); plt.xlabel('Failure Component'); plt.ylabel('Rotation'); plt.grid(True)
    st.pyplot(plt)

    plt.figure(figsize=(10, 6))
    plt.scatter(df_fail_join['failure'], df_fail_join['volt'], s=50, alpha=0.5)
    plt.title('Variation of Voltage wrt Failure Components'); plt.xlabel('Failure Component'); plt.ylabel('Voltage'); plt.grid(True)
    st.pyplot(plt)

    plt.figure(figsize=(10, 6))
    plt.scatter(mer['failure'], mer['vibration'], s=50, alpha=0.5)
    plt.title('Variation of Vibration wrt Failure Components'); plt.xlabel('Failure Component'); plt.ylabel('Vibration'); plt.grid(True)
    st.pyplot(plt)

    plt.figure(figsize=(10, 6))
    plt.scatter(mer['failure'], mer['age'], s=50, alpha=0.5)
    plt.title('Variation of Age wrt Failure Components'); plt.xlabel('Failure Component'); plt.ylabel('Age'); plt.grid(True)
    st.pyplot(plt)

# ---------------------------------------------------------------------------------
# Page 4 — Model building: show new columns + evaluate saved models
# ---------------------------------------------------------------------------------
def page4():
    st.title(":blue[MODEL BUILDING]")

    tele  = _read_csv_safe("Datasets/PdM_telemetry.csv", parse_dates=["datetime"])
    fails = _read_csv_safe("Datasets/PdM_failures.csv", parse_dates=["datetime"])
    errs  = _read_csv_safe("Datasets/PdM_errors.csv",   parse_dates=["datetime"])
    mnts  = _read_csv_safe("Datasets/PdM_maint.csv",    parse_dates=["datetime"])
    mach  = _read_csv_safe("Datasets/PdM_machines.csv")
    if tele.empty or fails.empty:
        return

    # 🔹 Augmented dataset with extra features (display clearly)
    merge_df = build_full_daily_dataset(tele, fails, errs, mnts, mach)
    cols_to_show = ['machineID','datetime','volt','rotate','pressure','vibration',
                    'failure','error_count','maint_count','err_last3','mnt_last7','age','model']
    st.subheader("Daily dataset with new features (used for training upgrades)")
    st.dataframe(merge_df[cols_to_show].head(300))
    st.caption("New columns added: error_count, maint_count, err_last3, mnt_last7, age, model.")

    st.divider()
    # Keep evaluation consistent with app’s current model (4 inputs)
    feature_cols = ['volt','rotate','pressure','vibration']
    merge_df = merge_df.set_index('datetime')
    X = merge_df[feature_cols]
    Y = merge_df['failure']

    X_train, X_test, Y_train, Y_test = train_test_split(
        X, Y, test_size=0.2, random_state=42, stratify=Y
    )

    rf = _load_model_fallback('models/rf_model.pkl')
    svc = _load_model_fallback('models/svc_pipeline.pkl')
    lr  = _load_model_fallback('models/logreg_model.pkl')
    ens = _load_model_fallback('models/ensemble_model.pkl')

    if rf is not None:
        st.header("Random Forest Classifier")
        y_pred = rf.predict(X_test)
        st.write("Accuracy: ", accuracy_score(Y_test, y_pred))
        st.write(confusion_matrix(Y_test, y_pred))

    st.divider()
    if svc is not None:
        st.header("Support Vector Classifier")
        y_pred = svc.predict(X_test)
        st.write("Accuracy: ", accuracy_score(Y_test, y_pred))
        st.write(confusion_matrix(Y_test, y_pred))

    st.divider()
    if lr is not None:
        st.header("Logistic Regression - newton-cg solver")
        y_pred = lr.predict(X_test)
        st.write("Accuracy: ", accuracy_score(Y_test, y_pred))
        st.write(confusion_matrix(Y_test, y_pred))

    st.divider()
    if ens is not None:
        st.header('Ensemble Model (thresholded)')
        thr = _load_threshold(default=0.5)
        prob = ens.predict_proba(X_test)[:, 1]
        y_pred_thr = (prob >= thr).astype(int)
        st.write(f"Accuracy (thr={thr:.2f}): ", accuracy_score(Y_test, y_pred_thr))
        st.write(confusion_matrix(Y_test, y_pred_thr))

    st.divider()
    cat = _load_model_fallback('models/catBoost.pkl')
    if cat is not None:
        st.header("CatBoost Classifier")
        y_pred = np.array(cat.predict(X_test)).astype(int)
        st.write("Accuracy", accuracy_score(Y_test, y_pred))
        st.write(confusion_matrix(Y_test, y_pred))

# ---------------------------------------------------------------------------------
# Page 5 — Failure prediction (manual inputs) → USE THRESHOLD & DATAFRAME INPUT
# ---------------------------------------------------------------------------------
def page5():
    st.title(':blue[FAILURE PREDICTION]')

    tele  = _read_csv_safe("Datasets/PdM_telemetry.csv", parse_dates=["datetime"])
    fails = _read_csv_safe("Datasets/PdM_failures.csv", parse_dates=["datetime"])
    errs  = _read_csv_safe("Datasets/PdM_errors.csv",   parse_dates=["datetime"])
    mnts  = _read_csv_safe("Datasets/PdM_maint.csv",    parse_dates=["datetime"])
    mach  = _read_csv_safe("Datasets/PdM_machines.csv")
    if tele.empty or fails.empty:
        return

    merge_df = build_full_daily_dataset(tele, fails, errs, mnts, mach)
    merge_df = merge_df.set_index('datetime')

    X = merge_df[['volt','rotate','pressure','vibration']]
    Y = merge_df['failure']
    # Not strictly required for prediction; retained for parity
    _ = train_test_split(X, Y, test_size=0.2, random_state=42, stratify=Y)

    st.write(tele.describe())

    # User inputs
    pressure  = st.number_input("Pressure",  min_value=0.0, format="%.6f")
    volt      = st.number_input("Volt",      min_value=0.0, format="%.6f")
    vibration = st.number_input("Vibration", min_value=0.0, format="%.6f")
    rotate    = st.number_input("Rotate",    min_value=0.0, format="%.6f")

    # >>> IMPORTANT: pass a DataFrame with named columns for ColumnTransformer pipelines
    feature_cols = ['volt','rotate','pressure','vibration']
    user_input_df = pd.DataFrame([{
        "volt": float(volt),
        "rotate": float(rotate),
        "pressure": float(pressure),
        "vibration": float(vibration),
    }])[feature_cols]

    ensemble_model = _load_model_fallback('models/ensemble_model.pkl')
    thr = _load_threshold(default=0.5)

    if st.button("Predict"):
        if ensemble_model is None:
            st.error("Model not loaded.")
            return
        if not (volt > 0 and rotate > 0 and pressure > 0 and vibration > 0):
            st.error("❌ One or more telemetry values are out of expected range.")
        else:
            probability = float(ensemble_model.predict_proba(user_input_df)[0][1])  # DF input
            y_label = int(probability >= thr)
            if y_label == 1:
                st.error(f"⚠️ Failure Predicted with Probability: **{probability:.2%}** (thr={thr:.2f})")
            else:
                st.success(f"✅ No Failure Predicted. Failure Probability: **{probability:.2%}** (thr={thr:.2f})")

# ---------------------------------------------------------------------------------
# Page 6 — Dashboard for multi-machine risk over time (show new columns)
# ---------------------------------------------------------------------------------
def page6():
    st.title("🔍 Machine Failure Risk Dashboard")

    tele  = _read_csv_safe("Datasets/PdM_telemetry.csv", parse_dates=["datetime"])
    fails = _read_csv_safe("Datasets/PdM_failures.csv", parse_dates=["datetime"])
    errs  = _read_csv_safe("Datasets/PdM_errors.csv",   parse_dates=["datetime"])
    mnts  = _read_csv_safe("Datasets/PdM_maint.csv",    parse_dates=["datetime"])
    mach  = _read_csv_safe("Datasets/PdM_machines.csv")
    if tele.empty or fails.empty:
        return

    merge_df = build_full_daily_dataset(tele, fails, errs, mnts, mach)
    failure_counts = merge_df.groupby('machineID')['failure'].sum()

    # Preview the new columns
    with st.expander("🔎 View data used for this dashboard (with new features)", expanded=False):
        cols_to_show = ['machineID','datetime','volt','rotate','pressure','vibration',
                        'failure','error_count','maint_count','err_last3','mnt_last7','age','model']
        st.dataframe(merge_df[cols_to_show].tail(300))

    model = _load_model_fallback("models/ensemble_model.pkl")
    if model is None:
        return

    recent_days = 90
    machine_ids = st.multiselect(
        "🛠️ Select Machine IDs to Evaluate",
        options=merge_df['machineID'].unique(),
    )

    if machine_ids:
        latest_data = merge_df.sort_values("datetime").groupby("machineID").tail(recent_days)
        selected_data = latest_data[latest_data['machineID'].isin(machine_ids)].copy()

        if selected_data.shape[0] < len(machine_ids) * recent_days:
            st.warning("⚠️ Some machines may not have telemetry data for the selected window.")

        feature_cols = ['volt','rotate','pressure','vibration']  # model expects 4 features
        selected_data['failure_probability'] = model.predict_proba(selected_data[feature_cols])[:, 1]

        def categorize_risk(p):
            if p >= 0.7: return "High 🔴"
            elif p >= 0.4: return "Medium 🟠"
            else: return "Low 🟢"

        max_proba = selected_data.groupby('machineID')['failure_probability'].max().reset_index()
        max_proba['Risk Level'] = max_proba['failure_probability'].apply(categorize_risk)

        max_proba = max_proba.merge(failure_counts, on='machineID', how='left')
        max_proba.rename(columns={
            'failure_probability': 'Max Failure Probability',
            'failure': 'Total Historical Failures'
        }, inplace=True)

        st.subheader("📊 Max Predicted Failure Probability")
        st.dataframe(max_proba.sort_values("Max Failure Probability", ascending=False))

        overall_max = max_proba['Max Failure Probability'].mean()
        st.markdown(f"### 🔥 Overall Max Failure Risk: `{overall_max:.2f}`")

        st.subheader("📈 Failure Probability Over Time")
        selected_data['datetime'] = pd.to_datetime(selected_data['datetime'])
        chart = alt.Chart(selected_data).mark_line(point=True).encode(
            x='datetime:T',
            y='failure_probability:Q',
            color='machineID:N',
            tooltip=['machineID', 'datetime', 'failure_probability',
                     'error_count','maint_count','err_last3','mnt_last7','age','model']
        ).properties(width=700)
        st.altair_chart(chart, use_container_width=True)
    else:
        st.info("Please select at least one machine ID to view predictions.")

# ---------------------------------------------------------------------------------
# Navigation
# ---------------------------------------------------------------------------------
pages = {
    "Telemetry": page1,
    "Errors": page2,
    "Machines, Failure + Telemetry": page3,
    "Model Building": page4,
    "Failure prediction": page5,   # manual inputs
    "Risk dashboard": page6
}
selection = st.sidebar.radio("Go to", list(pages.keys()))
pages[selection]()

# ---------------------------------------------------------------------------------
# ====================== AI PREDICT ADD-ON (appears under current page) ======================
# Extracts volt/rotate/pressure/vibration (Ollama Llama2 via LangChain, or regex fallback)
# and predicts using the same ensemble model + tuned threshold.

# Try multiple LangChain → Ollama import paths (supports newer/older LangChain)
try:
    from langchain_ollama import ChatOllama as _ChatOllama  # modern
except Exception:
    try:
        from langchain_community.chat_models import ChatOllama as _ChatOllama  # fallback
    except Exception:
        _ChatOllama = None  # use regex fallback

def _ai_get_llm():
    """Return ChatOllama instance if available, else None. Uses OLLAMA_MODEL (default: llama2)."""
    if _ChatOllama is None:
        return None
    model_name = os.environ.get("OLLAMA_MODEL", "llama2")
    try:
        return _ChatOllama(model=model_name, temperature=0)
    except Exception:
        return None

def _ai_extract_params(user_query: str):
    """
    Extract volt, rotate, pressure, vibration as floats.
    1) Try local LLM (Ollama) via LangChain with strict JSON output.
    2) Fall back to regex heuristics if LLM unavailable or parsing fails.
    Returns: dict {volt, rotate, pressure, vibration, source}
    """
    llm = _ai_get_llm()
    if llm is not None:
        sys = (
            "You extract 4 numeric fields from a maintenance query and return STRICT JSON only.\n"
            "Keys: volt, rotate, pressure, vibration. Values must be numbers or null. No extra text."
        )
        usr = (
            f"Query: {user_query}\n"
            "Return exactly: "
            '{"volt": number|null, "rotate": number|null, "pressure": number|null, "vibration": number|null}'
        )
        try:
            msg = llm.invoke([("system", sys), ("user", usr)])
            content = getattr(msg, "content", str(msg))
            m = _re.search(r"\{[\s\S]*\}", content)
            if m:
                data = json.loads(m.group(0))
                return {
                    "volt": None if data.get("volt") is None else float(data.get("volt")),
                    "rotate": None if data.get("rotate") is None else float(data.get("rotate")),
                    "pressure": None if data.get("pressure") is None else float(data.get("pressure")),
                    "vibration": None if data.get("vibration") is None else float(data.get("vibration")),
                    "source": "llm",
                }
        except Exception:
            pass  # fallback next

    def grab(pat):
        m = _re.search(pat, user_query, flags=_re.IGNORECASE)
        try:
            return float(m.group(1)) if m else None
        except Exception:
            return None

    candidates = {
        "volt":      grab(r"(?:volt|voltage)\s*[:=]?\s*([0-9]*\.?[0-9]+)"),
        "rotate":    grab(r"(?:rotate|rotation|rpm)\s*[:=]?\s*([0-9]*\.?[0-9]+)"),
        "pressure":  grab(r"(?:pressure|press)\s*[:=]?\s*([0-9]*\.?[0-9]+)"),
        "vibration": grab(r"(?:vibration|vibe|mm/?s)\s*[:=]?\s*([0-9]*\.?[0-9]+)"),
    }

    if sum(v is not None for v in candidates.values()) < 4:
        nums = _re.findall(r"([0-9]*\.?[0-9]+)", user_query)
        try:
            nums = [float(x) for x in nums[:4]]
            while len(nums) < 4:
                nums.append(None)
            v, r, p, vib = nums[:4]
            if candidates["volt"]      is None: candidates["volt"]      = v
            if candidates["rotate"]    is None: candidates["rotate"]    = r
            if candidates["pressure"]  is None: candidates["pressure"]  = p
            if candidates["vibration"] is None: candidates["vibration"] = vib
        except Exception:
            pass

    candidates["source"] = "regex"
    return candidates

def _ai_load_ensemble():
    """Load ensemble model with a path fallback. Returns model or None."""
    return _load_model_fallback('models/ensemble_model.pkl')

def render_predict_via_ai_section():
    st.divider()
    st.subheader("Predict via AI")
    nlq = st.text_area(
        "Describe your scenario (natural language)",
        height=120,
        placeholder="Example: For machine 12 in 2 days, volt 175, rotate 420, pressure 95, vibration 3.0 — what's the failure chance?"
    )

    if st.button("Predict via AI"):
        if not nlq.strip():
            st.warning("Please describe the scenario first.")
            return

        params = _ai_extract_params(nlq)
        volt_ai      = params.get("volt")
        rotate_ai    = params.get("rotate")
        pressure_ai  = params.get("pressure")
        vibration_ai = params.get("vibration")
        source       = params.get("source")

        st.info(f"Parsed (via **{source}**): volt={volt_ai}, rotate={rotate_ai}, pressure={pressure_ai}, vibration={vibration_ai}")
        missing = [k for k,v in [("volt", volt_ai), ("rotate", rotate_ai), ("pressure", pressure_ai), ("vibration", vibration_ai)] if v is None]
        if missing:
            st.error("Could not parse all required values: " + ", ".join(missing) + ". Please specify them explicitly.")
            return

        # >>> IMPORTANT: pass a DataFrame with named columns for ColumnTransformer pipelines
        feature_cols = ['volt','rotate','pressure','vibration']
        user_input_ai_df = pd.DataFrame([{
            "volt": float(volt_ai),
            "rotate": float(rotate_ai),
            "pressure": float(pressure_ai),
            "vibration": float(vibration_ai),
        }])[feature_cols]

        model = _ai_load_ensemble()
        if model is None:
            st.error("Model not found. Expected 'models/ensemble_model.pkl' (or nested 'models/models/').")
            return

        try:
            proba_ai  = float(model.predict_proba(user_input_ai_df)[0][1])  # DF input
            thr = _load_threshold(default=0.5)
            y_label = int(proba_ai >= thr)
            if y_label == 1:
                st.error(f"⚠️ Failure Predicted with Probability: **{proba_ai:.2%}** (thr={thr:.2f})")
            else:
                st.success(f"✅ No Failure Predicted. Failure Probability: **{proba_ai:.2%}** (thr={thr:.2f})")
        except Exception as e:
            st.error(f"Prediction failed: {type(e).__name__}: {e}")

# Show AI section on every page (at the end)
render_predict_via_ai_section()
# ====================== END AI PREDICT ADD-ON ======================
