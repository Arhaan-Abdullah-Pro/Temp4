# training_model.py  — minimal-change upgrade with extra features & robust saves
# - Trains TWO ensembles:
#   1) Realtime (4 inputs: volt, rotate, pressure, vibration)  -> models/ensemble_model.pkl   [used by app]
#   2) Full    (adds age, model, error/maint counts, daily agg)-> models/ensemble_full.pkl    [for improved use]
# - Re-exports base models (rf/svc/logreg) for both variants.
# - CatBoost optional: included if installed; otherwise skipped gracefully.
# - Handles paths & datasets robustly. Works on Windows.

from __future__ import annotations

import warnings
warnings.filterwarnings("ignore")

from pathlib import Path
import joblib
import numpy as np
import pandas as pd

from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, f1_score, roc_auc_score, classification_report
from sklearn.pipeline import Pipeline
from sklearn.compose import ColumnTransformer
from sklearn.preprocessing import StandardScaler, OneHotEncoder
from sklearn.impute import SimpleImputer
from sklearn.ensemble import RandomForestClassifier, VotingClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.svm import SVC

# ---- Optional CatBoost ----
try:
    from catboost import CatBoostClassifier
    HAVE_CATBOOST = True
except Exception:
    HAVE_CATBOOST = False

# ---- Paths ----
BASE_DIR   = Path(__file__).resolve().parent
DATA_DIR   = BASE_DIR / "Datasets"
MODELS_DIR = BASE_DIR / "models"
MODELS_DIR.mkdir(parents=True, exist_ok=True)

REALTIME_FEATURES = ["volt", "rotate", "pressure", "vibration"]  # <-- App uses these
TARGET_COL = "failure"

from sklearn.metrics import precision_score, recall_score, f1_score  # already imported f1_score, add if missing
import json

def choose_threshold(y_true, y_prob, target_recall=None):
    """
    Pick a classification threshold from validation probabilities.
    If target_recall is set, pick the *smallest* threshold that achieves it.
    Otherwise pick the threshold that maximizes F1.
    """
    thresholds = [round(t, 2) for t in list(np.linspace(0.05, 0.95, 19))]
    best = {"thr": 0.5, "f1": -1.0, "recall": 0.0, "precision": 0.0}
    if target_recall is not None:
        best = {"thr": 0.95, "f1": 0.0, "recall": 0.0, "precision": 0.0}  # we’ll try to go lower if possible
    for t in thresholds:
        yp = (y_prob >= t).astype(int)
        rec = recall_score(y_true, yp, zero_division=0)
        pre = precision_score(y_true, yp, zero_division=0)
        f1  = f1_score(y_true, yp, zero_division=0)
        if target_recall is not None:
            # choose the *smallest* t that meets recall target
            if rec >= target_recall and t < best["thr"]:
                best = {"thr": t, "f1": f1, "recall": rec, "precision": pre}
        else:
            if f1 > best["f1"]:
                best = {"thr": t, "f1": f1, "recall": rec, "precision": pre}
    return best

def save_threshold(stats: dict, path: Path):
    try:
        with open(path, "w", encoding="utf-8") as f:
            json.dump(stats, f, indent=2)
    except Exception as e:
        print(f"WARNING: failed to save threshold at {path}: {type(e).__name__}: {e}")


def _read_csv(name: str, parse_dt: bool = False) -> pd.DataFrame:
    p = DATA_DIR / name
    if not p.exists():
        # fallback if user runs from repo root location variants
        alt = Path.cwd() / "Datasets" / name
        p = alt if alt.exists() else p
    read_kwargs = {"low_memory": False}
    if parse_dt:
        read_kwargs["parse_dates"] = ["datetime"]
    df = pd.read_csv(p, **read_kwargs)
    return df

def load_raw() -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    telem   = _read_csv("PdM_telemetry.csv", parse_dt=True)
    machines= _read_csv("PdM_machines.csv", parse_dt=False)
    fails   = _read_csv("PdM_failures.csv", parse_dt=True)
    errors  = _read_csv("PdM_errors.csv", parse_dt=True)
    maint   = _read_csv("PdM_maint.csv", parse_dt=True)
    return telem, machines, fails, errors, maint

def build_daily_dataset(
    telem: pd.DataFrame, machines: pd.DataFrame, fails: pd.DataFrame, errors: pd.DataFrame, maint: pd.DataFrame
) -> pd.DataFrame:
    """Create a per-day per-machine table with target and features beyond telemetry."""
    # --- Telemetry daily aggregates ---
    t = telem.copy()
    t["datetime"] = pd.to_datetime(t["datetime"])
    t["date"] = t["datetime"].dt.floor("D")
    # daily mean for core features
    agg = t.groupby(["machineID", "date"], as_index=False).agg({
        "volt": "mean", "rotate": "mean", "pressure": "mean", "vibration": "mean"
    })

    # --- Failures: binary flag for that date ---
    f = fails.copy()
    f["datetime"] = pd.to_datetime(f["datetime"])
    f["date"] = f["datetime"].dt.floor("D")
    # if any failure on a day -> 1
    f_daily = (
        f.groupby(["machineID", "date"], as_index=False)
         .agg({ "failure": lambda x: 1 })
         .rename(columns={"failure": TARGET_COL})
    )

    # --- Errors/maintenance: daily counts ---
    e = errors.copy()
    e["datetime"] = pd.to_datetime(e["datetime"])
    e["date"] = e["datetime"].dt.floor("D")
    e_daily = e.groupby(["machineID", "date"], as_index=False).size().rename(columns={"size": "error_count"})

    m = maint.copy()
    m["datetime"] = pd.to_datetime(m["datetime"])
    m["date"] = m["datetime"].dt.floor("D")
    m_daily = m.groupby(["machineID", "date"], as_index=False).size().rename(columns={"size": "maint_count"})

    # --- Merge all daily on machineID+date ---
    df = agg.merge(f_daily, on=["machineID", "date"], how="left")
    df = df.merge(e_daily, on=["machineID", "date"], how="left")
    df = df.merge(m_daily, on=["machineID", "date"], how="left")
    df[TARGET_COL] = df[TARGET_COL].fillna(0).astype(int)
    df["error_count"] = df["error_count"].fillna(0).astype(int)
    df["maint_count"] = df["maint_count"].fillna(0).astype(int)

    # --- Add machine attributes (age, model) ---
    machines = machines.copy()
    # standardize model to str
    machines["model"] = machines["model"].astype(str)
    df = df.merge(machines, on="machineID", how="left")  # adds 'age','model'

    # --- Rolling features: recent 3-day sums of errors/maint (by machine) ---
    df = df.sort_values(["machineID", "date"])
    df["err_last3"] = (
        df.groupby("machineID")["error_count"].transform(lambda s: s.rolling(window=3, min_periods=1).sum())
    )
    df["mnt_last7"] = (
        df.groupby("machineID")["maint_count"].transform(lambda s: s.rolling(window=7, min_periods=1).sum())
    )

    # Drop rows with any missing core telemetry (rare if data is clean)
    return df.reset_index(drop=True)

def split_Xy(df: pd.DataFrame, feature_cols: list[str]) -> tuple[pd.DataFrame, pd.Series]:
    X = df[feature_cols].copy()
    y = df[TARGET_COL].copy()
    return X, y

def build_realtime_pipeline() -> VotingClassifier:
    """Realtime = only 4 numeric features. Pipelines with scaling where needed."""
    numeric = REALTIME_FEATURES
    pre = ColumnTransformer(
        transformers=[("num", Pipeline([("imputer", SimpleImputer(strategy="median")),
                                        ("scaler", StandardScaler())]), numeric)],
        remainder="drop"
    )

    rf = Pipeline([("pre", pre),
                   ("clf", RandomForestClassifier(n_estimators=300, class_weight="balanced", random_state=42))])

    svc = Pipeline([("pre", pre),
                    ("clf", SVC(C=1.0, kernel="rbf", probability=True, class_weight="balanced", random_state=42))])

    lr = Pipeline([("pre", pre),
                   ("clf", LogisticRegression(max_iter=200, class_weight="balanced", solver="lbfgs", random_state=42))])

    estimators = [("rf", rf), ("svc", svc), ("lr", lr)]
    if HAVE_CATBOOST:
        # CatBoost handles categorical internally; here realtime has only numeric -> still fine
        cat = Pipeline([("pre", pre),
                        ("clf", CatBoostClassifier(
                            iterations=400, depth=6, learning_rate=0.1, verbose=False,
                            loss_function="Logloss", auto_class_weights="Balanced"
                        ))])
        estimators.append(("cat", cat))

    ensemble = VotingClassifier(estimators=estimators, voting="soft", weights=None, flatten_transform=True)
    return ensemble

def build_full_pipeline(numeric_cols: list[str], categorical_cols: list[str]) -> VotingClassifier:
    """Full model: numeric + categorical with impute/scale/onehot."""
    pre = ColumnTransformer(
        transformers=[
            ("num", Pipeline([("imputer", SimpleImputer(strategy="median")),
                              ("scaler", StandardScaler())]), numeric_cols),
            ("cat", Pipeline([("imputer", SimpleImputer(strategy="most_frequent")),
                              ("onehot", OneHotEncoder(handle_unknown="ignore"))]), categorical_cols),
        ],
        remainder="drop"
    )

    rf = Pipeline([("pre", pre),
                   ("clf", RandomForestClassifier(n_estimators=350, class_weight="balanced", random_state=42))])

    svc = Pipeline([("pre", pre),
                    ("clf", SVC(C=1.0, kernel="rbf", probability=True, class_weight="balanced", random_state=42))])

    lr  = Pipeline([("pre", pre),
                    ("clf", LogisticRegression(max_iter=300, class_weight="balanced", solver="lbfgs", random_state=42))])

    estimators = [("rf", rf), ("svc", svc), ("lr", lr)]
    if HAVE_CATBOOST:
        cat = Pipeline([("pre", pre),
                        ("clf", CatBoostClassifier(
                            iterations=500, depth=6, learning_rate=0.1, verbose=False,
                            loss_function="Logloss", auto_class_weights="Balanced"
                        ))])
        estimators.append(("cat", cat))

    ens = VotingClassifier(estimators=estimators, voting="soft", weights=None, flatten_transform=True)
    return ens

def evaluate_and_log(name: str, model, X_test, y_test):
    y_prob = model.predict_proba(X_test)[:, 1]
    y_pred = (y_prob >= 0.5).astype(int)
    acc = accuracy_score(y_test, y_pred)
    f1  = f1_score(y_test, y_pred, zero_division=0)
    try:
        auc = roc_auc_score(y_test, y_prob)
    except Exception:
        auc = float("nan")
    print(f"\n=== {name} ===")
    print(f"Accuracy : {acc:.4f}")
    print(f"F1-score : {f1:.4f}")
    print(f"ROC AUC  : {auc:.4f}")
    print(classification_report(y_test, y_pred, target_names=["No Failure", "Failure"], zero_division=0))

def main():
    print("Loading raw datasets…")
    telem, machines, fails, errors, maint = load_raw()

    print("Building daily dataset with extra features…")
    df = build_daily_dataset(telem, machines, fails, errors, maint)

    # ---- Feature sets ----
    full_numeric = ["volt", "rotate", "pressure", "vibration", "age", "error_count", "maint_count", "err_last3", "mnt_last7"]
    full_categor = ["model"]

    # Ensure expected columns exist (robust against weird datasets)
    for col in full_numeric:
        if col not in df.columns:
            df[col] = np.nan
    for col in full_categor:
        if col not in df.columns:
            df[col] = ""

    # --- Realtime split (only 4 features) ---
    X_rt, y_rt = split_Xy(df, REALTIME_FEATURES)
    Xrt_train, Xrt_test, yrt_train, yrt_test = train_test_split(X_rt, y_rt, test_size=0.2, random_state=42, stratify=y_rt)

    # --- Full split (extra features) ---
    full_feats = full_numeric + full_categor
    X_full, y_full = split_Xy(df, full_feats)
    Xf_train, Xf_test, yf_train, yf_test = train_test_split(X_full, y_full, test_size=0.2, random_state=42, stratify=y_full)

    # ---- Train realtime ensemble (this is the one your app uses) ----
    print("\nTraining REALTIME ensemble (4 inputs)…")
    ens_rt = build_realtime_pipeline()
    ens_rt.fit(Xrt_train, yrt_train)
    evaluate_and_log("REALTIME Ensemble", ens_rt, Xrt_test, yrt_test)
    
        # ---- Pick & save threshold for REALTIME model ----
    y_prob_rt = ens_rt.predict_proba(Xrt_test)[:, 1]
    # Option 1: aim for better recall of failures (e.g., 0.50). Tweak as you like.
    rt_stats = choose_threshold(yrt_test, y_prob_rt, target_recall=0.50)
    # Option 2: or maximize F1 by using: rt_stats = choose_threshold(yrt_test, y_prob_rt, target_recall=None)

    print(f"Chosen REALTIME threshold = {rt_stats['thr']:.2f} | "
        f"F1={rt_stats['f1']:.3f}, Recall={rt_stats['recall']:.3f}, Precision={rt_stats['precision']:.3f}")
    save_threshold(rt_stats, MODELS_DIR / "threshold_realtime.json")


    # Save realtime ensemble and base members (rf/svc/lr)
    # Note: VotingClassifier pipelines don't expose members directly after fit in a standard attr,
    # but we can re-train the base pipelines quickly to export them consistently if required.
    print("Saving realtime artifacts…")
    joblib.dump(ens_rt, MODELS_DIR / "ensemble_model.pkl")  # <-- app loads this
    # (Optional) also export base estimators individually for compatibility:
    # Rebuild base pipelines and fit quickly on full rt-train to export:
    # (small time cost; comment out if not needed)
    def export_rt_base(pipe_builder, fname):
        m = pipe_builder()
        m.fit(Xrt_train, yrt_train)
        joblib.dump(m, MODELS_DIR / fname)

    # Builders for realtime base models
    def _rt_rf(): return Pipeline([("pre", ColumnTransformer(
        [("num", Pipeline([("imputer", SimpleImputer(strategy="median")),
                           ("scaler", StandardScaler())]), REALTIME_FEATURES)], remainder="drop")),
        ("clf", RandomForestClassifier(n_estimators=300, class_weight="balanced", random_state=42))])
    def _rt_svc(): return Pipeline([("pre", ColumnTransformer(
        [("num", Pipeline([("imputer", SimpleImputer(strategy="median")),
                           ("scaler", StandardScaler())]), REALTIME_FEATURES)], remainder="drop")),
        ("clf", SVC(C=1.0, kernel="rbf", probability=True, class_weight="balanced", random_state=42))])
    def _rt_lr():  return Pipeline([("pre", ColumnTransformer(
        [("num", Pipeline([("imputer", SimpleImputer(strategy="median")),
                           ("scaler", StandardScaler())]), REALTIME_FEATURES)], remainder="drop")),
        ("clf", LogisticRegression(max_iter=200, class_weight="balanced", solver="lbfgs", random_state=42))])

    export_rt_base(_rt_rf, "rf_model.pkl")
    export_rt_base(_rt_svc, "svc_pipeline.pkl")
    export_rt_base(_rt_lr,  "logreg_model.pkl")

    # ---- Train full ensemble (extra features) ----
    print("\nTraining FULL ensemble (extra features)…")
    ens_full = build_full_pipeline(full_numeric, full_categor)
    ens_full.fit(Xf_train, yf_train)
    evaluate_and_log("FULL Ensemble", ens_full, Xf_test, yf_test)
    
        # ---- Pick & save threshold for FULL model ----
    y_prob_full = ens_full.predict_proba(Xf_test)[:, 1]
    full_stats = choose_threshold(yf_test, y_prob_full, target_recall=0.50)
    print(f"Chosen FULL threshold = {full_stats['thr']:.2f} | "
        f"F1={full_stats['f1']:.3f}, Recall={full_stats['recall']:.3f}, Precision={full_stats['precision']:.3f}")
    save_threshold(full_stats, MODELS_DIR / "threshold_full.json")


    print("Saving full artifacts…")
    joblib.dump(ens_full, MODELS_DIR / "ensemble_full.pkl")
    # Optional: export bases for the full variant too
    # (names are suffixed with _full to avoid collisions)
    # Build base pipelines
    def _full_rf(): return Pipeline([("pre", ColumnTransformer(
        [("num", Pipeline([("imputer", SimpleImputer(strategy="median")),
                           ("scaler", StandardScaler())]), full_numeric),
         ("cat", Pipeline([("imputer", SimpleImputer(strategy="most_frequent")),
                           ("onehot", OneHotEncoder(handle_unknown="ignore"))]), full_categor)],
        remainder="drop")),
        ("clf", RandomForestClassifier(n_estimators=350, class_weight="balanced", random_state=42))])
    def _full_svc(): return Pipeline([("pre", ColumnTransformer(
        [("num", Pipeline([("imputer", SimpleImputer(strategy="median")),
                           ("scaler", StandardScaler())]), full_numeric),
         ("cat", Pipeline([("imputer", SimpleImputer(strategy="most_frequent")),
                           ("onehot", OneHotEncoder(handle_unknown="ignore"))]), full_categor)],
        remainder="drop")),
        ("clf", SVC(C=1.0, kernel="rbf", probability=True, class_weight="balanced", random_state=42))])
    def _full_lr():  return Pipeline([("pre", ColumnTransformer(
        [("num", Pipeline([("imputer", SimpleImputer(strategy="median")),
                           ("scaler", StandardScaler())]), full_numeric),
         ("cat", Pipeline([("imputer", SimpleImputer(strategy="most_frequent")),
                           ("onehot", OneHotEncoder(handle_unknown="ignore"))]), full_categor)],
        remainder="drop")),
        ("clf", LogisticRegression(max_iter=300, class_weight="balanced", solver="lbfgs", random_state=42))])

    joblib.dump(_full_rf().fit(Xf_train, yf_train), MODELS_DIR / "rf_full.pkl")
    joblib.dump(_full_svc().fit(Xf_train, yf_train), MODELS_DIR / "svc_full.pkl")
    joblib.dump(_full_lr().fit(Xf_train, yf_train), MODELS_DIR / "logreg_full.pkl")

    # ---- Optional CatBoost saves ----
    if HAVE_CATBOOST:
        # Refit CatBoost on realtime set for an optional artifact
        cat_rt = Pipeline([("pre", ColumnTransformer(
            [("num", Pipeline([("imputer", SimpleImputer(strategy="median")),
                               ("scaler", StandardScaler())]), REALTIME_FEATURES)], remainder="drop")),
            ("clf", CatBoostClassifier(
                iterations=400, depth=6, learning_rate=0.1, verbose=False,
                loss_function="Logloss", auto_class_weights="Balanced"
            ))])
        cat_rt.fit(Xrt_train, yrt_train)
        joblib.dump(cat_rt, MODELS_DIR / "catBoost.pkl")  # keeps old filename if app references it

        # And on full set too
        cat_full = Pipeline([("pre", ColumnTransformer(
            [("num", Pipeline([("imputer", SimpleImputer(strategy="median")),
                               ("scaler", StandardScaler())]), full_numeric),
             ("cat", Pipeline([("imputer", SimpleImputer(strategy="most_frequent")),
                               ("onehot", OneHotEncoder(handle_unknown="ignore"))]), full_categor)],
            remainder="drop")),
            ("clf", CatBoostClassifier(
                iterations=500, depth=6, learning_rate=0.1, verbose=False,
                loss_function="Logloss", auto_class_weights="Balanced"
            ))])
        cat_full.fit(Xf_train, yf_train)
        joblib.dump(cat_full, MODELS_DIR / "catBoost_full.pkl")

    print("\nAll models saved in:", MODELS_DIR.resolve())

if __name__ == "__main__":
    main()
