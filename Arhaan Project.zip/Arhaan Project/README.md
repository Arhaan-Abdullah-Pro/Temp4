# Predictive Maintenance — Final Project (Fixed)

## Setup
1. Create a fresh virtual environment (recommended).
2. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```

## Run
- Train (optional):
  ```bash
  python training_model.py
  ```
- Launch app:
  ```bash
  streamlit run final.py
  ```

## Predict via AI (optional)
- Install Ollama and pull a model:
  ```bash
  ollama pull llama2
  ```
- Set environment variable:
  - PowerShell: `$env:OLLAMA_MODEL="llama2"`
  - macOS/Linux: `export OLLAMA_MODEL=llama2`

If Ollama/LangChain aren't available, the app falls back to regex-based parsing.

## Health Check
Run a quick self-check:
```bash
python self_check.py
```
